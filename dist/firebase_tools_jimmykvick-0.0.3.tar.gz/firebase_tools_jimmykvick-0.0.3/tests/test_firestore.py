import pytest
from firebase_tools_jimmykvick.firestore import add_document

def test_add_document_valid(mocker):
  
  # mockear firestore_instance para que retorne un objeto falso
  mock_db = mocker.MagicMock()
  mock_doc_ref = mocker.MagicMock()
  mock_db.collection().document.return_value = mock_doc_ref
  mocker.patch('firebase_tools_jimmykvick.firestore.firestore_instance', return_value=mock_db)
  
  collection = "collection"
  body = { 'key': 'content' }
  
  doc_id = add_document(collection, body)
  
  mock_db.collection.assert_called_once_with(collection)
  mock_doc_ref.set.assert_called_once_with(body)
  
  assert doc_id is not None
